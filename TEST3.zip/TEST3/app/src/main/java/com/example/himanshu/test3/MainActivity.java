package com.example.himanshu.test3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.entity.StringEntity;
import java.io.InputStream;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONObject;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.os.AsyncTask;
import java.io.*;
import android.app.*;

public class MainActivity extends AppCompatActivity {
    private static String LOGIN_URL = "http://skoolog.com/teachers/sign_in.json";
   public String username = "";
    public String password = "";
    public String id="";
    String responseServer;
    // URL to get contacts JSON
EditText tv,tv1;
TextView t;
    private Button buttonOk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        tv=(EditText)findViewById(R.id.editText);
        tv1=(EditText)findViewById(R.id.editText2);
        String unam=tv.getText().toString();
      String upass=tv1.getText().toString();
               buttonOk = (Button)findViewById(R.id.button);
buttonOk.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        tv=(EditText)findViewById(R.id.editText);
        tv1=(EditText)findViewById(R.id.editText2);
      username=tv.getText().toString();
      password =tv1.getText().toString();
   //     t.setText("usr="+username+password);
        AsyncT asyncT = new AsyncT();
        asyncT.execute();
    }
});
        // ListView lv = getListView();

    }

    /* Inner class to get response */
    class AsyncT extends AsyncTask<Void, Void, Void> {


        @Override
        protected Void doInBackground(Void... voids) {
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(LOGIN_URL);
            httppost.setHeader("Content-Type", "application/json");

            try {

                JSONObject jsonobj = new JSONObject();
                JSONObject jsonobj1 = new JSONObject();
if(username.equalsIgnoreCase("9741211213") && password.equalsIgnoreCase("hello123")) {
    jsonobj.put("phone_number", username);
    jsonobj.put("password", password);
    jsonobj1.put("teacher", jsonobj);
    String jsonData=jsonobj1.toString();
    httppost.setEntity(new StringEntity(jsonData.toString()));
    // Execute HTTP Post Request
    HttpResponse response = httpclient.execute(httppost);
    InputStream inputStream = response.getEntity().getContent();
    //  InputStreamToStringExample str = new InputStreamToStringExample();
    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
    StringBuilder sb = new StringBuilder();


}

String jsonData=jsonobj1.toString().replace(",",", ");
                  Log.e("REQUEST SENT", jsonData);


                // Use UrlEncodedFormEntity to send in proper format which we need
               httppost.setEntity(new StringEntity(jsonData));
                       // Execute HTTP Post Request
                HttpResponse response = httpclient.execute(httppost);
                InputStream inputStream = response.getEntity().getContent();
              //  InputStreamToStringExample str = new InputStreamToStringExample();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder sb = new StringBuilder();

                String line = null;
                try {
                    while ((line = reader.readLine()) != null) {
                        sb.append(line + "\n");
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        inputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                responseServer = sb.toString();//str.getStringFromInputStream(inputStream);
                Log.e("response", "response -----" + responseServer);

id=sb.substring(17,18);
                Log.e("id=",id);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
Log.d("RESPONSE=",responseServer);
            if(username.equalsIgnoreCase("9741211213") && password.equalsIgnoreCase("hello123")) {
                Intent i = new Intent(MainActivity.this, Main2Activity.class);
                i.putExtra("ID",id);
                startActivity(i);
            }
            else
                Toast.makeText(MainActivity.this, "INVALID LOGIN..!", Toast.LENGTH_LONG).show();

            // txt.setText(responseServer);
        }
    }


}
