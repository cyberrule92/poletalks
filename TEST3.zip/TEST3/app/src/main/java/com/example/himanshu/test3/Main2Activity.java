package com.example.himanshu.test3;


import android.os.Bundle;
import android.app.Activity;

import android.util.Log;
import android.os.AsyncTask;

import android.view.View;
import android.widget.AdapterView;

import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import android.widget.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.*;


import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import android.view.*;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import android.app.ListActivity;
import org.json.JSONArray;
import org.json.JSONException;
import java.util.List;
import org.json.JSONObject;


public class Main2Activity extends Activity {

    String ver11;
    String name11;
    String reason;
    String date;
    String status;
    JSONArray a=null;
    String  strParsedValue="";
    String[] kk;
    ListView lvId;
    public String destroy,attr2;
    int absnt=0;
    public JSONObject c;
       ArrayList<HashMap<String, String>> oslist;
    TextView ver;
    TextView name,absentee;
    String hh="";
      @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
attr2=getIntent().getStringExtra("ID").toString();

        oslist = new ArrayList<HashMap<String, String>>();

        BackTaskGetJSON backTaskGetJSON= new BackTaskGetJSON();
        backTaskGetJSON.execute();
    }

    private void showResult(String jsonString){
        // Reference to the parent layout
        //Parse Json and show output


        Log.e("error=",hh);
                try {


            JSONObject jsnobject = new JSONObject(jsonString);

            Log.e("tag2",jsonString);

            for(int i=0;i<1;i++) {
                JSONObject object = jsnobject.getJSONObject("division");
TextView t=(TextView) findViewById(R.id.textView3);
                TextView t1=(TextView) findViewById(R.id.textView2);
              // Create layout to display the outlet info (id and name)
               Log.e("name",jsonString);
                String attr1 = object.getString("name");
                            //object.getString("id");
                t.setText("division:"+attr1);
                String attr3 = object.getString("student_count");
                String attr4 = object.getString("teacher");
                t1.setText("students:"+attr3+"\n"+"teacher:"+attr4+"\n");

            }

        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    //background process to get outlet info at remotee server
    private class BackTaskGetJSON extends AsyncTask<String,Void,Void> {
        String jsonString="";

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
            ver = (TextView)findViewById(R.id.vers);
            name = (TextView)findViewById(R.id.name);
            absentee=(TextView)findViewById(R.id.textView4);
        }

        protected Void doInBackground(String...params){

            try{
                HttpClient httpclient=new DefaultHttpClient();
                HttpGet httppost= new HttpGet("http://www.skoolog.com/divisions/1/attendance_list.json");
                ResponseHandler<String> responseHandler = new BasicResponseHandler();
                // Get json string from the url
                jsonString= httpclient.execute(httppost, responseHandler);

                Log.e("tag=",jsonString);
            }catch(Exception e){

                e.printStackTrace();
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void result){

            try{

               JSONObject jsnobject1 = new JSONObject(jsonString);

                a=jsnobject1.getJSONArray("student_leaves");
                hh="{"+jsonString.substring(75,978).toString().replace("student_leaves","student_leaves_attributes");


                for(int i = 0; i < 9; i++) {
                     c = a.getJSONObject(i);

                    // Storing  JSON item in a Variable
                    ver11 = c.getString("name");

                    name11 = c.getString("user_id");

                    reason = c.getString("reason");

                    date = c.getString("date");

                    status = c.getString("status");

                //    if(c.getString("_destroy").equalsIgnoreCase("true"))
                    destroy = c.getString("_destroy").replace("true","false");
                   //put("student_leaves_attributes",jObjectData);
                    Log.e("data=", ver11 + name11 + reason+ date + status + destroy);


                    //                   destroy="false";
                    // Adding value HashMap key => value

                    HashMap<String, String> map = new HashMap<String, String>();

                    map.put("name", ver11);
                    map.put("user_id", name11);

                    // map.put(TAG_API, api);


                    oslist.add(map);


                    lvId=(ListView) findViewById(R.id.listView);

                    ListAdapter adapter = new SimpleAdapter(Main2Activity.this, oslist,
                            R.layout.list_v,
                            new String[] { "name","user_id" }, new int[] {
                            R.id.vers,R.id.name});

                    lvId.setAdapter(adapter);
                    lvId.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                        @Override
                        public void onItemClick(AdapterView<?> parent, View view,
                                                int position, long id) {
                            try {
                                ++absnt;
                            Log.e("f=", a.getJSONObject(position).toString());
                                a.getJSONObject(position).getString("_destroy").replace("true","false");
                                a.getJSONObject(position).put("_destroy","false");
                                strParsedValue=a.toString();
                                Log.e("updated attendnce=", a.getJSONObject(position).toString());

                            }
                            catch (Exception e)
                            {
e.printStackTrace();
                            }

                          //  Log.e("finl=",strParsedValue);
                         Toast.makeText(Main2Activity.this, "You marked "+oslist.get(+position).get("name")+"Absent", Toast.LENGTH_LONG).show();

                        }
                    });

                }











            }
            catch (Exception e)
            {
                e.printStackTrace();
            }



            try{
                if(!jsonString.equals("")) {
                    // Parse json and show output
                    showResult(jsonString);
                                       Log.e("tag1=",jsonString);

                }
            }catch(Exception e){e.printStackTrace();}
        }

    }


    class AsyncT extends AsyncTask<Void, Void, Void> {


        @Override
        protected Void doInBackground(Void... voids) {
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("http://www.skoolog.com/divisions/update_attendance.json");
            try {


                String d="{"+"\"division\""+":"+"{student_leaves_attributes: "+strParsedValue+"}, "+"\"id\""+":"+attr2+"}";


                Log.e("UPDATED REQUEST SENT", d);
                Log.e("absnt="+absnt,"");
                // Use UrlEncodedFormEntity to send in proper format which we need
                httppost.setEntity(new StringEntity(d));
                // Execute HTTP Post Request
                HttpResponse response = httpclient.execute(httppost);
                InputStream inputStream = response.getEntity().getContent();
                //  InputStreamToStringExample str = new InputStreamToStringExample();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder sb = new StringBuilder();

                String line = null;
                try {
                    while ((line = reader.readLine()) != null) {
                        sb.append(line + "\n");
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        inputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
             String responseServer1 = sb.toString();//str.getStringFromInputStream(inputStream);
                Log.e("final_response", "response -----" + responseServer1);


            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }


    }



public void submit(View v)
{
    AsyncT asyncT = new AsyncT();
    asyncT.execute();
    absentee.setText("Absentees="+absnt);
}



}
